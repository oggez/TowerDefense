package uiTD;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

/**
 * Mob klassen sk�ter fienderna som springer runt p� banan.
 * @author oskar
 *
 */
public class Mob extends Rectangle {
	
	private GameLevel gameLvl;
	private int walkFrame = 0, walkSpeed = 5;
	private Image icon;
	
	private int xC, yC;
	
	private boolean slowed = false;
	private int mobWalk = 0;
	private int upward = 0, downward = 1, right = 2;
	private int direction = right;
	
	private int coinWorth;
	
	private int mobSize = 64;
	private int mobID = 0;
	private boolean inGame = false;
	private boolean dead = false;
	
	private int mobHP;
	private double lostHP = 0;
	private double percent = 0.04;
	private int startHP;
	private int mobHPbar = 50;
	
	
	public Mob(GameLevel gameLvl) {
		this.gameLvl = gameLvl;
		
	}
	
	
	public void spawnMob(int mobID, int waveCount, int levelCount){
		Block[][] block = gameLvl.getBlock();
		
		for(int i =0; i<block.length; i++){
			if(block[i][0].getID() > 0){
				setBounds(block[i][0].x, block[i][0].y, mobSize, mobSize);
				xC = 0;
				yC = i;
			}
		}
		this.mobID = mobID;
		if(this.mobID == 0){
			icon = new ImageIcon("files/pig.png").getImage();
			mobHP = 100 * waveCount * levelCount;
			startHP = 100 * waveCount * levelCount;
			coinWorth = 5;
		} else if( this.mobID == 1){
			icon = new ImageIcon("files/boss.png").getImage();
			mobHP = 5000 * levelCount;
			startHP = 5000 * levelCount;
			coinWorth = 100;
		}
		inGame = true;
		dead = false;
		
	}
	
	public void loseHealth(int hp){
		
		mobHP -= hp;
		lostHP += hp;
		checkDeath();
		
		if(!dead && startHP * percent < lostHP){
			mobHPbar -= 2;
			percent += 0.04;
		}
	}
	
	public void checkDeath(){
		if (!dead && mobHP < 0){
			inGame = false;
			dead = true;
			
			gameLvl.addCoin(coinWorth);
			if(mobID == 1){
				gameLvl.nextLevel();
			}
		}
	}
	
	public boolean dead(){
		return dead;
	}
	
	public boolean inGame(){
		return inGame;
	}
	
	public void slow(){
		slowed = true;
	}
	
	public void removeSlow(){
		slowed = false;
	}
	
	public void physic(){
		
		Block[][] block = gameLvl.getBlock();
		try {
			if (slowed) {
				walkSpeed = 20;
			} else if (!slowed){
				walkSpeed = 10;
			}

			if (walkFrame >= walkSpeed) {
				if (direction == right) {
					x += 1;
				} else if (direction == upward) {
					y -= 1;
				} else if (direction == downward) {
					y += 1;
				}

				mobWalk += 1;

				if (mobWalk == gameLvl.getBlockSize()) {
					if (direction == right) {
						xC += 1;
					} else if (direction == upward) {
						yC -= 1;
					} else if (direction == downward) {
						yC += 1;
					}

					if (block[yC][xC].getID() == 2) {
						direction = downward;

					} else if (block[yC][xC].getID() == 4 || block[yC][xC].getID() == 6 || block[yC][xC].getID() == 1) {
						direction = right;

					} else if (block[yC][xC].getID() == 5) {
						direction = upward;

					} else if (block[yC][xC].getID() == 7) {
						inGame = false;
						dead = true;
						gameLvl.removeHP(1);
						if(mobID == 1){
							gameLvl.removeHP(10);
						}

					}

					mobWalk = 0;
				}

				walkFrame = 0;
			} else {
				walkFrame += 1;
			}
		} catch (Exception e) {
		}

	}
	
	
	
	public void draw(Graphics g){
		if(inGame){
			g.drawImage(icon, x-6, y, width, height, null);
			g.setColor(Color.BLACK);
			g.drawRect(x + 4, y - 6, 51, 4);
			g.setColor(Color.RED);
			g.fillRect(x + 5, y - 5, 50, 3);
			g.setColor(Color.GREEN);
			g.fillRect(x + 5, y - 5, mobHPbar, 3);
			g.setColor(Color.BLACK);
			
		}
	}
}
