package uiTD;

import java.awt.Graphics;

public class GameLevel {
	public int worldWidth = 18;
	public int worldHeight = 8;
	public int blockSize = 64;
	
	public Block[][] block;
	
	public GameLevel(){
		define();
	}
	
	public void define(){
		block = new Block[worldHeight][worldWidth];
		
		for(int i = 0; i < block.length; i++){
			for(int y = 0; y < block[i].length; y++){
				
				block[i][y] = new Block((Game.myWidth/2) - ((worldWidth*blockSize)/2) + (y * blockSize), i* blockSize, blockSize, blockSize, 0);
				
			}
		}
	}
	
	public void physic(){
		
	}
	
	public void draw(Graphics g){
		for(int i = 0; i<block.length; i++){
			for(int y = 0; y<block[i].length;y++){
				
				block[i][y].draw(g);
				
			}
		}
	}
}
