package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;

/**
 * GameLevel klassen sk�ter det mesta och lagrar bilder osv.
 * @author oskar
 *
 */
public class GameLevel {
	private int worldWidth = 18;
	private int worldHeight = 8;
	private int blockSize = 64;
	private int coin = 10;
	private int hp = 10;
	private int nextLevel = 2;
	private int gameMode;
	
	private int levelCount = 1;
	private int maxLevel;
	private int waveCount = 1;
	
	private Save save;
	private Mob[] mobs = new Mob[11];
	
	private Image tower;
	private Image starEffect;
	private Image splash;
	private Image splashEffect;
	private Image splashBall;
	private Image slow;
	private Image slowEffect;
	private Image strong;
	
	private Image[] snow = new Image[8];
	private Image[] water = new Image[9];
	
	private boolean dead = false;
	private boolean deadMenu = false;
	private boolean win = false;
	private boolean winMenu = false;

	
	private Block[][] block;
	
	public GameLevel(Save save){
		define();
		this.save = save;
	}
	
	public void define(){
		block = new Block[worldHeight][worldWidth];
		tower = new ImageIcon("files/tower.png").getImage();
		starEffect = new ImageIcon("files/star.png").getImage();
		splash = new ImageIcon("files/splashKanon.png").getImage();
		splashEffect = new ImageIcon("files/splashEffect.png").getImage();
		splashBall = new ImageIcon("files/splashBall.png").getImage();
		slow = new ImageIcon("files/slow.png").getImage();
		slowEffect = new ImageIcon("files/slowEffect.png").getImage();
		strong = new ImageIcon("files/strong.png").getImage();
		
		for(int i = 0; i < snow.length; i++){
		snow[i] = new ImageIcon("files/snow" + i + ".jpg").getImage();
		}
		
		for(int i = 0; i < water.length; i++){
			water[i] = new ImageIcon("files/water" + i + ".jpg").getImage();
			}
		
		for(int i = 0; i < block.length; i++){
			for(int y = 0; y < block[i].length; y++){
				
				block[i][y] = new Block((Game.myWidth/2) - ((worldWidth*blockSize)/2) + (y * blockSize), i* blockSize, blockSize, blockSize, 0, this, mobs);
				
			}
		}
	}
	
	public void createMobs(){
		for(int i = 0; i<mobs.length; i++){
			mobs[i] = new Mob(this);
		}
	}
	
	public void setGameMode(int mode){
		gameMode = mode;
	}
	
	public void setMaxLevel(int level){
		maxLevel = level;
	}
	
	public int getGameMode(){
		return gameMode;
	}
	
	public void newGame(){
		hp = 10;
		dead = false;
		deadMenu = false;
		win = false;
		winMenu = false;
		waveCount = 1;
		levelCount = 1;
		mobSpawn = 0;
		coin = 10 * levelCount;
		
	}
	
	public void startWaterMission(int missionID){
		newGame();
		save.loadSave(new File("save/WaterMission" + missionID + ".td"), this);
		createMobs();
		
	}
	
	public void nextLevel(){
		levelCount ++;
		if(nextLevel ==1 && maxLevel == 0){
			save.loadSave(new File("save/mission" + nextLevel + ".td"), this);
		} else if(nextLevel == 2 && maxLevel == 0){
			save.loadSave(new File("save/mission" + nextLevel + ".td"), this);
		}
		createMobs();
		nextLevel = 1;
		waveCount = 1;
		mobSpawn = 0;
		coin = 10 * levelCount;
		
	}
	
	public Image getSnowImage(int i){
		return snow[i];
	}
	
	public Image getWaterImage(int i){
		return water[i];
	}
	
	public Image getTower(){
		return tower;
	}
	
	public Image getStarEffect(){
		return starEffect;
	}
	
	public Image getSplash(){
		return splash;
	}
	
	public Image getSplashEffect(){
		return splashEffect;
	}
	
	public Image getSplashBall(){
		return splashBall;
	}
	
	public Image getSlow(){
		return slow;
	}
	
	public Image getSlowEffect(){
		return slowEffect;
	}
	
	public Image getStrong(){
		return strong;
	}
	
	public void physic(){
		for(int i = 0; i<block.length; i++){
			for(int y = 0; y<block[i].length; y++){
				block[i][y].physic();
			}
		}
	}
	
	public boolean checkAllMobsDead(){
		boolean ret = true;
		for(int i = 0; i<mobs.length -1; i++){
			if(!mobs[i].dead()){
				ret = false;
			}
		}
		return ret;
	}
	
	public void draw(Graphics g){
		
		for(int i = 0; i<block.length; i++){
			for(int y = 0; y<block[i].length;y++){
				block[i][y].draw(g);
			}
		}
		
		for(int i = 0; i<block.length; i++){
			for(int y = 0; y<block[i].length;y++){
				block[i][y].fight(g);
			}
		}
		for(int i = 0; i<block.length; i++){
			for(int y = 0; y<block[i].length;y++){
				block[i][y].rangeAnimation();
			}
		}
		
		
		for(int i = 0 ; i < mobs.length; i++){
			if(mobs[i].inGame()){
				mobs[i].draw(g);
			}
		}
		
		g.setFont(new Font("Courier New", Font.BOLD, 18));
		g.setColor(Color.WHITE);
		g.drawString("Level " + levelCount , 1150, 560 );
		g.drawString("Wave  " + waveCount , 1150, 600 );
		
		g.setColor(Color.BLACK);
		g.drawLine(block[0][0].x, block[0][0].y, block[7][0].x, block[7][0].y + blockSize);
		g.drawLine(block[7][0].x, block[7][0].y + blockSize , block[7][17].x + blockSize, block[7][17].y + blockSize);
		g.drawLine(block[7][17].x + blockSize, block[7][17].y + blockSize, block[0][17].x + blockSize, block[0][17].y);
		
	}
	
	private int spawnTime = 1000, spawnFrame = 0, nextWave = 1000, mobSpawn = 0;
	public void mobSpawner(){
		
		if(spawnFrame >= spawnTime && nextWave == 1000 && !deadMenu && !dead && (levelCount <= maxLevel || maxLevel == 0)){
			if(mobSpawn < (mobs.length-1)){
				mobs[mobSpawn].spawnMob(0, waveCount, levelCount);
				mobSpawn += 1;
				
			} else if (mobSpawn == (mobs.length -1)&& waveCount < 10 && checkAllMobsDead()){
				mobSpawn = 0;
				waveCount++;
				createMobs();
				nextWave = 0;
				
			} else if(waveCount == 10 && checkAllMobsDead()) {
				mobs[mobSpawn].spawnMob(1, waveCount, levelCount);
				waveCount ++;
			}
			spawnFrame = 0;
		} else if (nextWave != 1000){
			nextWave += 1;
		} else {
			spawnFrame += 1;
		}
		
		for (int i = 0; i < mobs.length; i++) {
			if (mobs[i].inGame()) {
				mobs[i].physic();
			}
		}
		
	}
	
	public Block[][] getBlock(){
		return block;
	}
	
	public int getBlockSize(){
		return blockSize;
	}
	
	public int getHP(){
		return hp;
	}
	
	public void removeHP(int amount){
		if(hp > 0){
			hp -= amount;
		}
		
		if(hp <= 0){
			deadMenu = true;
		}
	}
	public boolean dead(){
		return dead;
	}
	
	public boolean deadMenu(){
		return deadMenu;
	}
	
	public void setWinMenu(){
		winMenu = true;
	}
	
	public void setDefeat(){
		dead = true;
	}
	
	public void setWin(){
		if(maxLevel > 0 && levelCount == maxLevel){
			win = true;
			winMenu = false;
		} else {
			winMenu = false;
			nextLevel();
		}
	}
	
	public boolean win(){
		return win;
	}
	
	public boolean winMenu(){
		return winMenu;
	}
	
	public int getCoin(){
		return coin;
	}
	
	public void addCoin(int amount){
		coin += amount;
	}
	
	public void removeCoin(int amount){
		coin -= amount;
	}
	
	public int getLevel(){
		return levelCount;
	}
	
	public int getMaxLevel(){
		return maxLevel;
	}
	
	public int getWave(){
		return waveCount;
	}
}
