package uiTD;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class LevelUI extends JPanel{
	private GameFrame frame;
	private Image level;
	
	public LevelUI(GameFrame frame){
		this.frame = frame;
		level = new ImageIcon("files/levelMap.jpg").getImage();
	}
	
	public void paintComponent(Graphics g){
		g.drawImage(level, 0, 0, getWidth(), getHeight(), null);
	}
	
	
	private class ML implements MouseListener{

		public void mouseClicked(MouseEvent arg0) {
			
		}

		public void mouseEntered(MouseEvent arg0) {
			
		}

		public void mouseExited(MouseEvent arg0) {
			
		}

		public void mousePressed(MouseEvent arg0) {
			
		}

		public void mouseReleased(MouseEvent arg0) {
			
		}
		
	}
}


