package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Menu {
	private Image bkGround;
	private Image logo;
	private Rectangle[] btn = new Rectangle[3];
	private int btnX = 200;
	private int btnY = 50;
	private int btnSpace = 10;
	private Point mse = new Point(0, 0);
	
	private Game game;
	
	public Menu(Game game){
		bkGround = new ImageIcon("files/background_menu.jpg").getImage();
		logo = new ImageIcon("files/LogoDicusT.png").getImage();
		this.game = game;
		
		for(int i = 0; i<btn.length; i++){
			btn[i] = new Rectangle(Game.myWidth/2 - btnX/2, Game.myHeight/2 + 100 + ((btnY+btnSpace)*i), btnX, btnY);
		}
	}
	
	public void setMse(Point mse){
		this.mse = mse; 
	}
	
	public void click(int mouseBtn){
		if(mouseBtn == 1){
			if(btn[0].contains(mse)&& game.inMenu()){
				game.goAdventureModeMenu();
				
			} else if(btn[1].contains(mse)&& game.inMenu()){
				game.startGameEndless();
				
			} else if(btn[2].contains(mse)&& game.inMenu()){
				System.exit(0);
			}
		}
	}
	
	public void draw(Graphics g){
		g.drawImage(bkGround, 0, 0, Game.myWidth, Game.myHeight, null);
		g.drawImage(logo, Game.myWidth/2 - logo.getWidth(null)/2, 0, null);
		
		for(int i = 0; i < btn.length; i++){
			g.fillRect(btn[i].x, btn[i].y, btn[i].width, btn[i].height);
		}
		
		g.setFont(new Font("Courier New", Font.BOLD, 18));
		g.setColor(Color.WHITE);
		
		g.drawString("Adventure mode", btn[0].x + 10, btn[0].y + btnY/2);
		g.drawString("Endless mode", btn[1].x + 10, btn[1].y + btnY/2);
		g.drawString("Exit", btn[2].x + 10, btn[2].y + btnY/2);
		g.setColor(Color.BLACK);
		
	}

}
