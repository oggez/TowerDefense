package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class AdventureMenu {
	private Image[] waterAdv = new Image[3];
	private Rectangle[] advRect = new Rectangle[3];
	
	private Image btnImage;
	private Image btnEntered;
	
	private Image waterBkGround;
	private Game game;
	
	private Rectangle bkToMenu;
	
	private Point mse = new Point(0, 0);
	
	
	
	public AdventureMenu(Game game){
		waterBkGround = new ImageIcon("files/waterBkGround.jpg").getImage();
		btnImage = new ImageIcon("files/btn.png").getImage();
		btnEntered = new ImageIcon("files/btnEntered.png").getImage();
		this.game = game;
		bkToMenu = new Rectangle(50, Game.myHeight - 100, 270, 90);
		
		for(int i = 0; i< waterAdv.length; i++){
			waterAdv[i] = new ImageIcon("files/waterAdv" + i + ".png").getImage();
			
		}
		
		for(int i = 0; i<advRect.length ; i++){
			advRect[i] = new Rectangle(100 + (300*i), 100, 100, 100);
		}
	}
	
	public void setMse(Point point){
		mse = point;
	}
	
	public void click(int mouseBtn){
		if(bkToMenu.contains(mse)&& game.inAdventureMenu() && mouseBtn == 1){
			game.goMainMenu();
		} else if(advRect[0].contains(mse) && game.inAdventureMenu() && mouseBtn == 1){
			game.startWaterMission(1);
		} else if(advRect[1].contains(mse) && game.inAdventureMenu() && mouseBtn == 1){
			game.startWaterMission(2);
		} else if(advRect[2].contains(mse) && game.inAdventureMenu() && mouseBtn == 1){
			game.startWaterMission(3);
		}
	}
	
	
	public void draw(Graphics g){
		g.drawImage(waterBkGround, 0, 0, Game.myWidth, Game.myHeight, null);
		
		if(bkToMenu.contains(mse)&& game.inAdventureMenu()){
			g.drawImage(btnEntered, bkToMenu.x, bkToMenu.y , bkToMenu.width, bkToMenu.height, null);
		} else {
			g.drawImage(btnImage, bkToMenu.x, bkToMenu.y , bkToMenu.width, bkToMenu.height, null);
		}
		g.setFont(new Font("Verdana", Font.BOLD, 20));
		g.setColor(new Color(42, 20, 3));
		g.drawString("Main Menu", bkToMenu.x + 70, (bkToMenu.y + bkToMenu.height/2) + 7);
		
		
		g.drawImage(waterAdv[0], 100, 100, null);
		g.drawString("Level 1", 105, 95);
		g.drawImage(waterAdv[1], 400, 100, null);
		g.drawString("Level 2", 405, 95);
		g.drawImage(waterAdv[2], 700, 100, null);
		g.drawString("Level 3", 705, 95);
		
		g.setColor(new Color(255, 254, 145));
		g.drawLine(150, 150, 450, 150);
		g.drawLine(450, 150, 750, 150);
		
		
		g.setColor(Color.BLACK);
	}

}
