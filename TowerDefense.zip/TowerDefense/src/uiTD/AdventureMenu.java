package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class AdventureMenu {
	private Image[] waterAdv = new Image[3];
	private Rectangle[] advRect = new Rectangle[3];
	
	private Image waterBkGround;
	private Game game;
	
	private Rectangle bkToMenu;
	
	private Point mse = new Point(0, 0);
	
	public AdventureMenu(Game game){
		waterBkGround = new ImageIcon("files/waterBkGround.jpg").getImage();
		this.game = game;
		bkToMenu = new Rectangle(50, Game.myHeight - 100, 200, 50);
		
		for(int i = 0; i< waterAdv.length; i++){
			waterAdv[i] = new ImageIcon("files/waterAdv" + i + ".png").getImage();
			
		}
		
		for(int i = 0; i<advRect.length ; i++){
			advRect[i] = new Rectangle(100 + (300*i), 100, 100, 100);
		}
	}
	
	public void setMse(Point point){
		mse = point;
	}
	
	public void click(int mouseBtn){
		if(bkToMenu.contains(mse)&& game.inAdventureMenu() && mouseBtn == 1){
			game.goMainMenu();
		} else if(advRect[0].contains(mse) && game.inAdventureMenu() && mouseBtn == 1){
			game.startWaterMission(1);
		} else if(advRect[1].contains(mse) && game.inAdventureMenu() && mouseBtn == 1){
			game.startWaterMission(2);
		} else if(advRect[2].contains(mse) && game.inAdventureMenu() && mouseBtn == 1){
			game.startWaterMission(3);
		}
	}
	
	
	public void draw(Graphics g){
		g.drawImage(waterBkGround, 0, 0, Game.myWidth, Game.myHeight, null);
		
		
		g.fillRect(bkToMenu.x, bkToMenu.y , bkToMenu.width, bkToMenu.height);
		g.setColor(Color.WHITE);
		g.setFont(new Font("Courier New", Font.BOLD, 18));
		g.drawString("to Menu", bkToMenu.x + 10, bkToMenu.y + bkToMenu.height/2);
		
//		g.drawRect(advRect[1].x, advRect[1].y, advRect[1].width, advRect[1].height);
		
		g.drawImage(waterAdv[0], 100, 100, null);
		g.drawString("Level 1", 105, 95);
		g.drawImage(waterAdv[1], 400, 100, null);
		g.drawString("Level 2", 405, 95);
		g.drawImage(waterAdv[2], 700, 100, null);
		g.drawString("Level 3", 705, 95);
		
		g.setColor(new Color(255, 254, 145));
		g.drawLine(150, 150, 450, 150);
		g.drawLine(450, 150, 750, 150);
		
		
		g.setColor(Color.BLACK);
	}

}
