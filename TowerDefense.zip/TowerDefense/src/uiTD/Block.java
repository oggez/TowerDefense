package uiTD;

import java.awt.Graphics;
import java.awt.Rectangle;

public class Block extends Rectangle{
	
	public int id;
	
	public Block(int x, int y, int width, int height, int id){
		setBounds(x, y, width, height);
		this.id = id;
	}
	
	
	public void draw(Graphics g){
		g.drawImage(Game.ground, x, y, width, height, null);
		
		if(id == 1){
			g.drawImage(Game.air, x, y, width, height, null);
		}
		
		
	}
	
}
