package uiTD;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.LinkedList;

/**
 * H�ller reda p� vad som finns i alla block om det �r en ex v�g/tower.
 * @author oskar
 *
 */
public class Block extends Rectangle{
	
	private int id;
	private Rectangle tdRange;
	private Rectangle splashRange;
	private GameLevel gameLvl;
	
	private int cordX;
	private int cordY;
	
	
	private LinkedList<Integer> mobArray = new LinkedList<Integer>();
	private int animationTarget;
	private boolean shoting = false;
	private int loseFrame = 0, loseTime = 50;
	private int shootFrame = 0, shootTime = 1;

	private Mob[] mobs;
	
	public Block(int x, int y, int width, int height, int id, GameLevel gameLvl, Mob[] mobs){
		setBounds(x, y, width, height);
		this.gameLvl = gameLvl;
		this.id = id;
		this.mobs = mobs;
		tdRange = new Rectangle();
		cordY = y + 20;
		cordX = x + 20;
	}
	/**
	 * physics �r en metod som k�rs genom Game tr�den och h�ller reda p� om en fiende g�r att attackera
	 * och vilken fiende som ska attackeras n�sta g�ng.
	 */
	public void physic() {
		if (id < 0) {	
			if (!mobArray.isEmpty() && !tdRange.intersects(mobs[mobArray.getFirst()])) {
				shoting = false;
				mobs[mobArray.getFirst()].removeSlow();
				mobArray.remove();
			}

			for (int i = 0; i < mobs.length; i++) {
				if (tdRange.intersects(mobs[i]) && mobs[i].inGame()) {
					shoting = true;
					if(!mobArray.contains(i)){
						mobArray.add(i);
					}
				}
			}
			
			if (shoting) {
				
				/**
				 * RangeTower ID -1
				 */
				if (id == -1) {
					if (loseFrame >= loseTime) {
						mobs[mobArray.getFirst()].loseHealth(3);
						loseFrame = 0;
						
					} else {
						loseFrame++;
					}

					/**
					 * SplashTower ID -2
					 */
				} else if (id == -2) {
					if (loseFrame >= loseTime) {
						splashRange = new Rectangle(mobs[mobArray.getFirst()].x + 32 - 50 , mobs[mobArray.getFirst()].y + 32 - 50, 100, 100);
						
						for (int i = 0; i < mobs.length; i++) {
							if (splashRange.intersects(mobs[i])) {
								mobs[i].loseHealth(2);
							}
						}
						
						loseFrame = 0;

					} else {
						loseFrame++;
					}

					/**
					 * SlowTower ID -3
					 */
				} else if (id == -3) {
					if (loseFrame >= loseTime) {

						for (int i = 0; i < mobs.length; i++) {
							if (tdRange.intersects(mobs[i])) {
								mobs[i].slow();
							}
						}
						loseFrame = 0;
					} else {
						loseFrame++;
					}

					/**
					 * StrongTower ID -4
					 */
				} else if (id == -4) {
					if (loseFrame >= loseTime) {

						mobs[mobArray.getFirst()].loseHealth(10);
						loseFrame = 0;

					} else {
						loseFrame++;
					}
				}
				
				if (!mobs[mobArray.getFirst()].inGame()) {
					shoting = false;
					mobs[mobArray.getFirst()].removeSlow();
					mobArray.remove();
				}

			}
		}
	}
	
	/**
	 * rangeAnimation metoden uppdaterar v�rden s�
	 * att "kulorna" fr�n tornen f�ljer fienderna.
	 */
	public void rangeAnimation(){
		try {
			if (shootFrame >= shootTime && shoting) {
				if (animationTarget != mobArray.getFirst()) {
					animationTarget = mobArray.getFirst();
					cordX = x + 20;
					cordY = y + 20;
				}
				if ((cordX == mobs[animationTarget].x + 12 && cordY == mobs[animationTarget].y + 12)) {
					cordX = x + 20;
					cordY = y + 20;
				}

				if (cordX > mobs[animationTarget].x + 12) {
					cordX--;
				} else if (cordX < mobs[animationTarget].x + 12) {
					cordX++;
				}

				if (cordY > mobs[animationTarget].y + 12) {
					cordY--;
				} else if (cordY < mobs[animationTarget].y + 12) {
					cordY++;
				}
				shootFrame = 0;
			} else {
				shootFrame++;
			}
		} catch (Exception E) {}
	}
	
	/**
	 * Ritar upp hur blocket ska se ut beroende p� vilken ID som s�tts
	 * @param g
	 */
	public void draw(Graphics g){
		
		
		if(gameLvl.getGameMode() == 1){
			if(id < 10 && id >= 0){
				g.drawImage(gameLvl.getSnowImage(id), x, y, width, height, null);
			
			} else if(id == -1){
				g.drawImage(gameLvl.getSnowImage(0), x, y, width, height, null);
				g.drawImage(gameLvl.getTower(), x, y, width, height, null);
				tdRange = new Rectangle(x+ 32 - 250 , y + 32 - 250, 500, 500);
			
			} else if(id == -2){
				g.drawImage(gameLvl.getSnowImage(0), x, y, width, height, null);
				g.drawImage(gameLvl.getSplash(), x, y, width, height, null);
				tdRange = new Rectangle(x + 32 - 150 , y + 32 - 150, 300, 300);
				
			} else if(id == -3){
				g.drawImage(gameLvl.getSnowImage(0), x, y, width, height, null);
				g.drawImage(gameLvl.getSlow(), x, y, width, height, null);
				tdRange = new Rectangle(x + 32 - 150 , y + 32 - 150, 300, 300);
				
			} else if(id == -4){
				g.drawImage(gameLvl.getSnowImage(0), x, y, width, height, null);
				g.drawImage(gameLvl.getStrong(), x, y, width, height, null);
				tdRange = new Rectangle(x + 32 - 75 , y + 32 - 75, 150, 150);
			}
		} else if (gameLvl.getGameMode() == 2){
			if(id < 10 && id >= 0){
				g.drawImage(gameLvl.getWaterImage(id), x, y, width, height, null);
			
			} else if(id == -1){
				g.drawImage(gameLvl.getWaterImage(8), x, y, width, height, null);
				g.drawImage(gameLvl.getTower(), x, y, width, height, null);
				tdRange = new Rectangle(x+ 32 - 250 , y + 32 - 250, 500, 500);
			
			} else if(id == -2){
				g.drawImage(gameLvl.getWaterImage(8), x, y, width, height, null);
				g.drawImage(gameLvl.getSplash(), x, y, width, height, null);
				tdRange = new Rectangle(x + 32 - 150 , y + 32 - 150, 300, 300);
				
			} else if(id == -3){
				g.drawImage(gameLvl.getWaterImage(8), x, y, width, height, null);
				g.drawImage(gameLvl.getSlow(), x, y, width, height, null);
				tdRange = new Rectangle(x + 32 - 150 , y + 32 - 150, 300, 300);
				
			} else if(id == -4){
				g.drawImage(gameLvl.getWaterImage(8), x, y, width, height, null);
				g.drawImage(gameLvl.getStrong(), x, y, width, height, null);
				tdRange = new Rectangle(x + 32 - 75 , y + 32 - 75, 150, 150);
			}
		}
		
		
	}
	private int pulseCount = 300;
	/**
	 * metoden fight ritar upp de olika fight animationerna som sker n�r tornen attackerar.
	 * @param g
	 */
	public void fight(Graphics g){
		if(shoting){
			if(id == -1){
				g.drawImage(gameLvl.getStarEffect(), cordX, cordY, 20, 20, null);
				
			} else if(id == -2){
//				g.drawImage(gameLvl.getSplashEffect(), Game.mobs[mobArray.getFirst()].x - 50 , Game.mobs[mobArray.getFirst()].y - 50, Game.mobs[mobArray.getFirst()].width + 100, Game.mobs[mobArray.getFirst()].height + 100, null);
				g.drawImage(gameLvl.getSplashBall(), cordX, cordY, 20, 20, null);
			} else if(id == -3){
				
					g.drawImage(gameLvl.getSlowEffect(), tdRange.x + pulseCount/2, tdRange.y+ pulseCount/2, tdRange.width - pulseCount , tdRange.height - pulseCount , null);
					pulseCount --;
					if(pulseCount == 0){
						pulseCount = 300;
					}
			} else if(id == -4){
				g.setColor(Color.CYAN);
				g.drawLine(x + (width/2), y + (height/2) - 30, mobs[mobArray.getFirst()].x + (mobs[mobArray.getFirst()].width/2), mobs[mobArray.getFirst()].y + (mobs[mobArray.getFirst()].height/2));
				g.setColor(Color.BLACK);
			}
		}
	}
	
	public int getID(){
		return id;
	}
	
	public void setID(int id){
		this.id = id;
	}
	
	public Rectangle getRange(){
		return tdRange;
	}
}
