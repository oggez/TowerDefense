package uiTD;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

public class MenuUI extends JPanel {
	private JPanel btnPnl;
	private Image img;
	private Image imgLogo;
	private JButton btnAdventure;
	private JButton btnEndless;
	private JButton btnOption;
	private JButton btnExit;
	private JFrame frame;
	
	
	public MenuUI(JFrame frame){

		setLayout(null);
		try {
			img = ImageIO.read(new File("files/background_menu.jpg"));
			imgLogo = ImageIO.read(new File("files/LogoDicusT.png"));
		} catch (IOException e) {}
		initComponents();
		initPanels();
		initListeners();
	}
	
	public void initComponents(){	
		btnAdventure = new JButton("Start Adventure");
		btnEndless = new JButton("Start Endless");
		btnOption = new JButton("Option");
		btnExit = new JButton(new ImageIcon("files/btnExit.png"));
		btnExit.setBorderPainted(false);
		btnExit.setFocusPainted(false);
		btnExit.setContentAreaFilled(false);
		
	}
	
	public void initPanels(){
		
		btnPnl = new JPanel(new GridLayout(4, 1, 0, 10 ));
		btnPnl.setOpaque(false);	
		btnPnl.add(btnAdventure);
		btnPnl.add(btnEndless);
		btnPnl.add(btnOption);
		btnPnl.add(btnExit);
		btnPnl.setBounds(1280/2 - 100, 720 - 250 , 200 ,150);
		add(btnPnl);
		
	}
	
	public void paintComponent(Graphics g) {
	    super.paintComponent(g); 
	    g.drawImage( img, 0, 0, this.getWidth(), this.getHeight(), null );
	    g.drawImage( imgLogo, this.getWidth()/2 - imgLogo.getWidth(null)/2 , 15, null );
	    
	}
	
	public void initListeners(){
		AL listener = new AL();
		btnAdventure.addActionListener(listener);
		btnEndless.addActionListener(listener);
		btnOption.addActionListener(listener);
		btnExit.addActionListener(listener);
	}
	
	private class AL implements ActionListener{

		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == btnAdventure){
				AdventureUI adv = new AdventureUI(frame);
				
				
			} else if (e.getSource() == btnEndless){
				
			} else if (e.getSource() == btnOption){
				
			} else if (e.getSource() == btnExit){
				System.exit(0);
			}
			
		}
		
	}
}
