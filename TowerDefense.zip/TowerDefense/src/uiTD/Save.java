package uiTD;

import java.io.File;
import java.util.Scanner;

/**
 * Save klassen l�ser in missions fr�n Save mappen.
 * @author oskar
 *
 */
public class Save {
	
	public void loadSave(File loadPath, GameLevel gameLvl){
		try {
			Scanner loadScanner = new Scanner(loadPath);
			Block[][] block = gameLvl.getBlock();
				
			gameLvl.setGameMode(loadScanner.nextInt());
			gameLvl.setMaxLevel(loadScanner.nextInt());
			for(int i = 0; i< block.length; i++){
				for(int y = 0; y < block[i].length; y++){
						
					block[i][y].setID(loadScanner.nextInt());
				}
			}			
			loadScanner.close();
		} catch (Exception e) {}
	}
}
