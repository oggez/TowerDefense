package uiTD;

import java.io.File;
import java.util.Scanner;

public class Save {
	
	public void loadSave(File loadPath){
		try {
			Scanner loadScanner = new Scanner(loadPath);
			
			while(loadScanner.hasNext()){
				
				for(int i = 0; i< Game.level.block.length; i++){
					for(int y = 0; y < Game.level.block[i].length; y++){
						
						Game.level.block[i][y].id = loadScanner.nextInt();
					}
				}			
			}
			
			loadScanner.close();
		} catch (Exception e) {}
		
	}
}
