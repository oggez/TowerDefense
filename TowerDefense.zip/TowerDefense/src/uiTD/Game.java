package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import javax.swing.JPanel;

/**
 * Game klassen �r JPanel delen samt d�r Game tr�den startas.
 * @author oskar
 *
 */
public class Game extends JPanel implements Runnable {
	private Thread gameThread = new Thread(this);

	public static int myWidth, myHeight;
	
	private boolean isFirst = true;
	private GameLevel level;
	private Save save;
	private Store store;
	private GameFrame frame;
	
	
	public Game(GameFrame frame){
		this.frame = frame;
		gameThread.start();
		
	}
	
	public void define(){
		save = new Save();
		level = new GameLevel(save);
		store = new Store(level);
		
		frame.addMouseListener(new KeyHandler(store));
		frame.addMouseMotionListener(new KeyHandler(store));
		
		save.loadSave(new File("save/mission1.td"), level);
		level.createMobs();
	}
	
	
	public void paintComponent(Graphics g){
		if(isFirst){
			myWidth = getWidth();
			myHeight = getHeight();
			define();
			isFirst = false;
		}
		
		g.setColor(new Color(70, 70, 70));
		g.fillRect(0, 0, getWidth(), getHeight());
		g.setColor(Color.BLACK);
		 
		level.draw(g);
		store.draw(g);
		
		if(level.dead()){
			g.setFont(new Font("Courier New", Font.BOLD, 100));
			g.setColor(Color.RED);
			g.drawString("YOU LOSE!!" , 100, 100 );
			g.setColor(Color.BLACK);
		}
	}
	

	
	public void run() {
		while (!Thread.interrupted()) {
			if (!isFirst) {
				level.physic();
				level.mobSpawner();
				if(level.dead()){
					gameThread.interrupt();
				}
			}

			repaint();
			
			

			try {
				Thread.sleep(1);
			} catch (Exception e) {
			}
		}
	}
}
