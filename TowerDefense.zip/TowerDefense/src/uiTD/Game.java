package uiTD;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Game extends JPanel implements Runnable {
	public Thread gameThread = new Thread(this);
	
	public static Image ground;
	public static Image air;
	public static Image tower;
	public static Image health;
	public static Image coins;
	
	
	public static int myWidth, myHeight;
	
	public static boolean isFirst = true;
	
	public static Point mse = new Point(0, 0);
	
	public static GameLevel level;
	public static Save save;
	public static Store store;
	
	
	public Game(GameFrame frame){
		frame.addMouseListener(new KeyHandler());
		frame.addMouseMotionListener(new KeyHandler());
		
		gameThread.start();
		
	}
	
	public void define(){
		level = new GameLevel();
		save = new Save();
		store = new Store();
		
		air = new ImageIcon("files/road.jpg").getImage();
		ground = new ImageIcon("files/grass.jpg").getImage();
		tower = new ImageIcon("files/tower.png").getImage();
		coins = new ImageIcon("files/coin.png").getImage();
		health = new ImageIcon("files/heart.png").getImage();

		save.loadSave(new File("save/mission1.td"));
	}
	
	public void paintComponent(Graphics g){
		if(isFirst){
			myWidth = getWidth();
			myHeight = getHeight();
			define();
			isFirst = false;
		}
		
		g.setColor(new Color(70, 70, 70));
		g.fillRect(0, 0, getWidth(), getHeight());
		
		g.setColor(Color.BLACK);
		 
		level.draw(g);
		store.draw(g);
	}
	
	
	public void run(){
		while(true){
			if(!isFirst){
				level.physic();
			}
			
			repaint();
			
			try{
			Thread.sleep(1);
			} catch(Exception e){ }
		}
	}
}
