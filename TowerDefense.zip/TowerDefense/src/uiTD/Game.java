package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.File;
import java.util.Random;

import javax.swing.JPanel;

/**
 * Game klassen �r JPanel delen samt d�r Game tr�den startas.
 * @author oskar
 *
 */
public class Game extends JPanel implements Runnable {
	private Thread gameThread = new Thread(this);

	public static int myWidth, myHeight;
	
	private boolean isFirst = true;
	
	private boolean inMenu = true;
	private boolean inGame = false;
	private boolean inAdventureMenu = false;
	
	private Random rand = new Random();
	private GameLevel level;
	private Save save;
	private Store store;
	private AdventureMenu aMenu;
	private GameFrame frame;
	private Menu menu;
	
	
	public Game(GameFrame frame){
		this.frame = frame;
		gameThread.start();
		
	}
	
	public void define(){
		save = new Save();
		level = new GameLevel(save);
		store = new Store(level, this);
		menu = new Menu(this);
		aMenu = new AdventureMenu(this);
		
		frame.addMouseListener(new KeyHandler(store, menu, aMenu, this));
		frame.addMouseMotionListener(new KeyHandler(store, menu, aMenu, this));
		frame.addKeyListener(new KeyHandler(store, menu, aMenu, this));
	}
	
	
	public void paintComponent(Graphics g){
		if(isFirst){
			myWidth = getWidth();
			myHeight = getHeight();
			define();
			isFirst = false;
		}
		
		if (inGame) {
			g.setColor(new Color(50, 50, 50));
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.BLACK);

			level.draw(g);
			store.draw(g);
		} else if(inMenu){
			menu.draw(g);
			
		} else if(inAdventureMenu){
			aMenu.draw(g);
		}
	}
	
	public void startWaterMission(int missionID){
		level.startWaterMission(missionID);
		inMenu = false;
		inGame = true;
		inAdventureMenu = false;
	}
	
	public void startGameEndless(){
		level.newGame();
		
		save.loadSave(new File("save/mission" + (rand.nextInt(4)+1) + ".td"), level);
		level.createMobs();
		inMenu = false;
		inGame = true;
		inAdventureMenu = false;
	}
	
	public void goAdventureModeMenu(){
		inMenu = false;
		inAdventureMenu = true;
		inGame = false;
	}
	
	public void goMainMenu(){
		inMenu = true;
		inGame = false;
		inAdventureMenu = false;
	}
	
	public boolean inMenu(){
		return inMenu;
	}
	
	public boolean inGame(){
		return inGame;
	}
	
	public boolean inAdventureMenu(){
		return inAdventureMenu;
	}
	

	
	public void run() {
		while (!Thread.interrupted()) {
			
			if (!isFirst) {
				
				if(inGame){
					level.physic();
					level.mobSpawner();
					
					if (level.dead()) {
						goMainMenu();
					} else if(level.win()){
						goMainMenu();
					}
					
				} else if(inMenu){
					
				} else if(inAdventureMenu){
					
				}
				
			}
			
			repaint();
			try {
				Thread.sleep(1);
			} catch (Exception e) {}
		}
	}
}
