package uiTD;

import javax.swing.JFrame;

public class AdventureUI {
	
	public AdventureUI(JFrame frame){
		
	}

}
