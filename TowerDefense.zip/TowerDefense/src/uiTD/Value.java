package uiTD;

public class Value {
	public static int groundGrass = 0;
	
	public static int airAir = -1;

}
