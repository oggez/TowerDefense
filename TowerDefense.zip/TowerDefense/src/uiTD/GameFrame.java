package uiTD;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JFrame;

/**
 * Skapar JFrame rutan
 * @author oskar
 *
 */
public class GameFrame extends JFrame{
	
	private String title = "Tower Defense: DicusT";
	private Dimension size = new Dimension(1280, 720);
	
	public GameFrame(){
		setTitle(title);
		setSize(size);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		init();
	}
	
	public void init(){
		setLayout(new GridLayout(1, 1, 0, 0));
		Game game = new Game(this);
		add(game);
		setVisible(true);
		
	}
	
	public static void main(String[] args){
		GameFrame frame = new GameFrame();		
	}
}
