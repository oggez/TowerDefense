package uiTD;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/**
 * Keyhandler lyssnar efter input fr�n datormusen.
 * @author oskar
 *
 */
public class KeyHandler implements MouseMotionListener, MouseListener {
	private Store store;
	
	public KeyHandler(Store store){
		this.store = store;
	}

	public void mouseClicked(MouseEvent e) {
		
	}

	public void mouseEntered(MouseEvent e) {
		
	}

	public void mouseExited(MouseEvent e) {
		
	}

	public void mousePressed(MouseEvent e) {
		store.click(e.getButton());
		
	}

	public void mouseReleased(MouseEvent e) {
		
	}


	public void mouseDragged(MouseEvent e) {
		store.setMse(new Point((e.getX()) + ((1280 - Game.myWidth)/2), (e.getY()) + ((720 - Game.myHeight)/2) - 13 ));
		
	}

	public void mouseMoved(MouseEvent e) {
		store.setMse(new Point((e.getX()) - ((1280 - Game.myWidth)/2), (e.getY()) - ((720 - Game.myHeight)/2) - 13 ));
		
	}
	
	
}
