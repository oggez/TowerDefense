package uiTD;

import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

/**
 * Keyhandler lyssnar efter input fr�n datormusen.
 * @author oskar
 *
 */
public class KeyHandler implements MouseMotionListener, MouseListener, KeyListener {
	private Store store;
	private Menu menu;
	private AdventureMenu advMenu;
	private Game game;
	
	public KeyHandler(Store store, Menu menu, AdventureMenu advMenu, Game game){
		this.store = store;
		this.menu = menu;
		this.advMenu = advMenu;
		this.game = game;
	}

	public void mouseClicked(MouseEvent e) {
		
	}

	public void mouseEntered(MouseEvent e) {
		
	}

	public void mouseExited(MouseEvent e) {
		
	}

	public void mousePressed(MouseEvent e) {
		if(game.inGame()){
			store.click(e.getButton());
			
		} else if(game.inMenu()){
			
			menu.click(e.getButton());
		} else if(game.inAdventureMenu()){
			
			advMenu.click(e.getButton());
		}
		
	}

	public void mouseReleased(MouseEvent e) {
		
	}


	public void mouseDragged(MouseEvent e) {
		if(game.inGame()){
			store.setMse(new Point((e.getX()) + ((1280 - Game.myWidth)/2), (e.getY()) + ((720 - Game.myHeight)/2) - 13 ));
		} else if(game.inMenu()){
			menu.setMse(new Point((e.getX()) + ((1280 - Game.myWidth)/2), (e.getY()) + ((720 - Game.myHeight)/2) - 13 ));
		} else if(game.inAdventureMenu()){
			advMenu.setMse(new Point((e.getX()) + ((1280 - Game.myWidth)/2), (e.getY()) + ((720 - Game.myHeight)/2) - 13 ));
		}
	}

	public void mouseMoved(MouseEvent e) {
		if(game.inGame()){
			store.setMse(new Point((e.getX()) - ((1280 - Game.myWidth)/2), (e.getY()) - ((720 - Game.myHeight)/2) - 13 ));
			
		}  else if(game.inMenu()){
			menu.setMse(new Point((e.getX()) - ((1280 - Game.myWidth)/2), (e.getY()) - ((720 - Game.myHeight)/2) - 13 ));
			
		} else if(game.inAdventureMenu()){
			advMenu.setMse(new Point((e.getX()) - ((1280 - Game.myWidth)/2), (e.getY()) - ((720 - Game.myHeight)/2) - 13 ));
			
		}
	}

	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_ESCAPE && game.inGame()){
			store.menu();
		}
	}

	public void keyReleased(KeyEvent e) {
		
		
	}

	public void keyTyped(KeyEvent e) {
		
		
	}
	
	
}
