package uiTD;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class KeyHandler implements MouseMotionListener, MouseListener {

	public void mouseClicked(MouseEvent e) {
		
	}

	public void mouseEntered(MouseEvent e) {
		
	}

	public void mouseExited(MouseEvent e) {
		
	}

	public void mousePressed(MouseEvent e) {
		
	}

	public void mouseReleased(MouseEvent e) {
		
	}


	public void mouseDragged(MouseEvent e) {
		Game.mse = new Point((e.getX()) + ((GameFrame.size.width - Game.myWidth)/2) , (e.getY()) + ((GameFrame.size.height - Game.myHeight)/2));
	}

	public void mouseMoved(MouseEvent e) {
		Game.mse = new Point((e.getX()) -  ((GameFrame.size.width - Game.myWidth)/2) , (e.getY()) - ((GameFrame.size.height - Game.myHeight)/2));
		
	}
	
	
}
