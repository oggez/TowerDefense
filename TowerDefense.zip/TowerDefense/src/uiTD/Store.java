package uiTD;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Store {
	public static int shopWidth = 4;
	public static int buttonSize = 64;
	public static int cellSpace = 5;
	
	public Rectangle[] button = new Rectangle[shopWidth];
	public Rectangle btnHealth;
	public Rectangle btnCoins;
	
	public Store(){
		define();
		
	}
	
	
	public void define(){
		
		for(int i = 0; i<button.length; i++){
			button[i] = new Rectangle((Game.myWidth/2) - ((shopWidth*buttonSize)/2) + (( buttonSize + cellSpace)*i), 570, buttonSize, buttonSize);
		}
		
		
		btnHealth = new Rectangle((Game.myWidth/2) - ((shopWidth*buttonSize)*2) + (( buttonSize)), 520, buttonSize, buttonSize);
		btnCoins = new Rectangle((Game.myWidth/2) - ((shopWidth*buttonSize)*2) + (( buttonSize)), 600, buttonSize, buttonSize);
		
		
	}
	
	public void draw(Graphics g){
		
		for(int i = 0; i<button.length; i++){
			g.fillRect(button[i].x, button[i].y, button[i].width, button[i].height);
			g.drawImage(Game.tower, button[i].x, button[i].y, button[i].width, button[i].height, null);
		}
		
		for(int i = 0; i<button.length; i++){
			if(button[i].contains(Game.mse)){
				g.setColor(new Color(255, 255, 255, 100));
				g.fillRect(button[i].x, button[i].y, button[i].width, button[i].height);
			}
		}
		
		g.drawImage(Game.health, btnHealth.x, btnHealth.y, btnHealth.width, btnHealth.height, null);
		g.drawImage(Game.coins, btnCoins.x, btnCoins.y, btnCoins.width, btnCoins.height, null);
		
		
	}

}
