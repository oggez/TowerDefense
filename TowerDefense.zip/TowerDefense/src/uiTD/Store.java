package uiTD;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

/**
 * Klassen Store sk�ter allting som har med shoppen att g�ra.
 * Dess funktion samt att rita upp den i f�nstret.
 * @author oskar
 *
 */
public class Store {
	private GameLevel gameLvl;
	private Block[][] block;
	
	private Point mse = new Point(0, 0);
	
	private int shopWidth = 4;
	private int buttonSize = 64;
	private int cellSpace = 5;
	
	private int rangeCost = 10;
	private int splashCost = 20;
	private int slowCost = 30;
	private int strongCost = 50;
	
	private int heldID = 0;
	private boolean holdsItem = false;
	
	private int[] buttonId = {-1, -2, -3, -4};
	
	private Rectangle[] button = new Rectangle[shopWidth];
	
	private Image health;
	private Image coins;
	private Rectangle btnHealth;
	private Rectangle btnCoins;
	
	
	public Store(GameLevel gameLvl){
		coins = new ImageIcon("files/coin.png").getImage();
		health = new ImageIcon("files/heart.png").getImage();
		
		this.gameLvl = gameLvl;
		block = gameLvl.getBlock();
		define();
		
	}
	
	public void setMse(Point mse){
		this.mse = mse; 
	}
	
	public void click(int mouseButton){
		
		if(holdsItem && mouseButton == 1){
			for(int i = 0; i<block.length; i++){
				for(int y = 0; y<block[i].length; y++){
					if(block[i][y].contains(mse) && holdsItem && block[i][y].getID() == 0){
						
						if(heldID == -1 && gameLvl.getCoin() >= rangeCost){
							gameLvl.removeCoin(rangeCost);
							block[i][y].setID(heldID);
							holdsItem = false;
						} else if(heldID == -2 && gameLvl.getCoin() >= splashCost){
							gameLvl.removeCoin(20);
							block[i][y].setID(heldID);
							holdsItem = false;
						} else if(heldID == -3 && gameLvl.getCoin() >= slowCost){
							gameLvl.removeCoin(30);
							block[i][y].setID(heldID);
							holdsItem = false;
						} else if(heldID == -4 && gameLvl.getCoin() >= strongCost){
							gameLvl.removeCoin(40);
							block[i][y].setID(heldID);
							holdsItem = false;
						}
					}
				}
			}
		} else if(mouseButton == 1 && !holdsItem){
			for(int i = 0; i<button.length; i++){
				if(button[i].contains(mse)){
					heldID = buttonId[i];
					holdsItem = true;
				}
			}
		} else if(mouseButton == 3){
			heldID = 0;
			holdsItem = false;
		}
	}
	
	
	public void define(){
		
		for(int i = 0; i<button.length; i++){
			button[i] = new Rectangle((Game.myWidth/2) - ((shopWidth*buttonSize)/2) + (( buttonSize + cellSpace)*i), 570, buttonSize, buttonSize);
		}
		
		
		btnHealth = new Rectangle(block[0][0].x - 1, button[0].y - buttonSize + 30, buttonSize - 20, buttonSize - 20);
		btnCoins = new Rectangle(block[0][0].x - 1, button[0].y + 35 , buttonSize - 20, buttonSize - 20);
		
		
	}
	
	public void draw(Graphics g){
		
		
		g.fillRect(button[0].x, button[0].y, button[0].width, button[0].height);
		g.drawImage(gameLvl.getTower(), button[0].x, button[0].y, button[0].width, button[0].height, null);
		
		g.fillRect(button[1].x, button[1].y, button[1].width, button[1].height);
		g.drawImage(gameLvl.getSplash(), button[1].x, button[1].y, button[1].width, button[1].height, null);
		
		g.fillRect(button[2].x, button[2].y, button[2].width, button[2].height);
		g.drawImage(gameLvl.getSlow(), button[2].x, button[2].y, button[2].width, button[2].height, null);
		
		g.fillRect(button[3].x, button[3].y, button[3].width, button[3].height);
		g.drawImage(gameLvl.getStrong(), button[3].x, button[3].y, button[3].width, button[3].height, null);
		
		g.setFont(new Font("Courier New", Font.BOLD, 18));
		g.setColor(Color.WHITE);
		g.drawString("$ " + rangeCost , button[0].x, button[0].y -5);
		g.drawString("$ " + splashCost , button[1].x, button[1].y -5);
		g.drawString("$ " + slowCost, button[2].x, button[2].y -5);
		g.drawString("$ " + strongCost, button[3].x, button[3].y -5);
		g.setColor(Color.BLACK);
		
		for(int i = 0; i<button.length; i++){
			if(button[i].contains(mse)){
				g.setColor(new Color(255, 255, 255, 100));
				g.fillRect(button[i].x, button[i].y, button[i].width, button[i].height);
				
			}
		}
		
		
		for(int i = 0; i<block.length; i++){
			for(int y = 0; y<block[i].length; y++){
				
				if(block[i][y].contains(mse) && holdsItem){
					if(heldID == -1 && gameLvl.getCoin() >= rangeCost && block[i][y].getID() == 0){
						g.setColor(new Color(0, 255, 0, 100) );
						g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					} else if(heldID == -2 && gameLvl.getCoin() >= splashCost && block[i][y].getID() == 0){
						g.setColor(new Color(0, 255, 0, 100));
						g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					} else if(heldID == -3 && gameLvl.getCoin() >= slowCost && block[i][y].getID() == 0){
						g.setColor(new Color(0, 255, 0, 100));
						g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					} else if(heldID == -4 && gameLvl.getCoin() >= strongCost && block[i][y].getID() == 0){
						g.setColor(new Color(0, 255, 0, 100));
						g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					} else {
						g.setColor(new Color(255, 0, 0, 100));
						g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					}
				}
				
				
				if (block[i][y].contains(mse) && block[i][y].getID() == -1 && !holdsItem){
					g.setColor(new Color(255, 255, 255, 100));
					g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					g.setColor(Color.GREEN);
					g.drawRect(block[i][y].getRange().x, block[i][y].getRange().y, block[i][y].getRange().width, block[i][y].getRange().height);				
				} else if (block[i][y].contains(mse) && block[i][y].getID() == -2 && !holdsItem){
					
					g.setColor(new Color(255, 255, 255, 100));
					g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					g.setColor(Color.GREEN);
					g.drawRect(block[i][y].getRange().x, block[i][y].getRange().y, block[i][y].getRange().width, block[i][y].getRange().height);				
				} else if (block[i][y].contains(mse) && block[i][y].getID() == -3 && !holdsItem){
					
					g.setColor(new Color(255, 255, 255, 100));
					g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					g.setColor(Color.GREEN);
					g.drawRect(block[i][y].getRange().x, block[i][y].getRange().y, block[i][y].getRange().width, block[i][y].getRange().height);				
				} else if (block[i][y].contains(mse) && block[i][y].getID() == -4 && !holdsItem){
					
					g.setColor(new Color(255, 255, 255, 100));
					g.fillRect(block[i][y].x, block[i][y].y, block[i][y].width, block[i][y].height);
					g.setColor(Color.GREEN);
					g.drawRect(block[i][y].getRange().x, block[i][y].getRange().y, block[i][y].getRange().width, block[i][y].getRange().height);				
				}
				
			}
		}
		
		g.drawImage(health, btnHealth.x, btnHealth.y, btnHealth.width, btnHealth.height, null);
		g.drawImage(coins, btnCoins.x, btnCoins.y, btnCoins.width, btnCoins.height, null);
		
		g.setColor(Color.WHITE);
		g.setFont(new Font("Courier New", Font.BOLD, 18));
		g.drawString("" + gameLvl.getHP(), btnHealth.x + btnHealth.width + 5, btnHealth.y + 20);
		g.drawString("" + gameLvl.getCoin(), btnCoins.x + btnCoins.width + 5, btnCoins.y + 25);
		g.setColor(Color.BLACK);
		
		if(holdsItem && heldID == -1){
			g.drawImage(gameLvl.getTower(), mse.x - 25, mse.y - 30, button[0].width, button[0].height, null);
			for(int i = 0; i<block.length; i++){
				for(int y = 0; y<block[i].length; y++){
					if(block[i][y].contains(mse) && holdsItem && block[i][y].getID() == 0){
						g.setColor(Color.GREEN);
						g.drawRect(block[i][y].x + 32 - 250 , block[i][y].y + 32 - 250, 500, 500);
						
					}
				}
			}
		}
		else if(holdsItem && heldID == -2){
			g.drawImage(gameLvl.getSplash(), mse.x - 25, mse.y - 30, button[1].width, button[1].height, null);
			for(int i = 0; i<block.length; i++){
				for(int y = 0; y<block[i].length; y++){
					if(block[i][y].contains(mse) && holdsItem && block[i][y].getID() == 0){
						g.setColor(Color.GREEN);
						g.drawRect(block[i][y].x + 32 - 150 , block[i][y].y + 32 - 150, 300, 300);
						
					}
				}
			}
		}
		else if(holdsItem && heldID == -3){
			g.drawImage(gameLvl.getSlow(), mse.x - 25, mse.y - 30, button[1].width, button[1].height, null);
			for(int i = 0; i<block.length; i++){
				for(int y = 0; y<block[i].length; y++){
					if(block[i][y].contains(mse) && holdsItem && block[i][y].getID() == 0){
						g.setColor(Color.GREEN);
						g.drawRect(block[i][y].x + 32 - 150 , block[i][y].y + 32 - 150, 300, 300);
						
					}
				}
			}
		}
		else if(holdsItem && heldID == -4){
			g.drawImage(gameLvl.getStrong(), mse.x - 25, mse.y - 30, button[1].width, button[1].height, null);
			for(int i = 0; i<block.length; i++){
				for(int y = 0; y<block[i].length; y++){
					if(block[i][y].contains(mse) && holdsItem && block[i][y].getID() == 0){
						g.setColor(Color.GREEN);
						g.drawRect(block[i][y].x + 32 - 75 , block[i][y].y + 32 - 75, 150, 150);
						
					}
				}
			}
		}
	}
}
